Name: Pablo Argallero Fernández
UO : 283216
Exercise model asigned : 1
Implemented use cases:
	-Contract
	-Contract type
List of ampliation exercises implemented:
	-Extraction of JPA annotations to XML orm.xml file
	
Comments:
	-Problems encountered 
	-test modifications and their explanation
	
####################
PROBLEMS ENCOUNTERED
####################
	I had a problem with the maven. Sometimes it gives an error but if the maven 
	projects are updated and/or reinstalled it gives no errors
	
	Some warnings due to JDK version appeared while developing the task. I could not
	fix them since they were related to the jdk and the jdk is correctly configured. 
	These warnings do not affect the final product.
	
	In the delivery y included also all the projects: services, tests, menu ones and util
	Since I made changes in some of the tests -> explained bellow. I also posted a doubt on the 
	forum regarding this concern and in order to not miss anything I included all in the zip file.
	I hope it is not an issue.

##################
TEST MODIFICATIONS
##################
	-------------------------
	--DOMAIN TESTS EXTENDED--
	-------------------------
 InvoiceTest -> line 68 -> use of assertEquals instead of == due to rounding error
	PREVIOUS LINE 68 -> assertTrue(invoice.getAmount() == 468.88); // 2 cents rounded
	NEW LINE 68 -> assertEquals(468.88, invoice.getAmount(), 0.01); 
	
 InvoiceTest -> line 93 -> use of assertEquals instead of == due to rounding error
	PREVIOUS LINE 93 -> assertTrue( invoice.getAmount() ==  468.88 ); // 2 cents rounding
	NEW LINE 93 -> assertEquals(468.88, invoice.getAmount(), 0.01);
	
 InvoicingSteps -> line 265 -> use of assertEquals again to avoid rounding error
	PREVIOUS LINE 265 -> assertTrue(found.total == expectedInvoice.total);
	NEW LINE 265 -> assertEquals(expectedInvoice.total, found.total, 0.1);
	
	---------------------------
	--EXTENSION TESTS CHANGES--
	---------------------------
 DeleteSteps -> line 40 -> it calls the delete mechanic passing the dni instead of the id 
	as the service interface dettermines
	PREVIOUS LINE 40 -> service.deleteMechanic(mechanic.dni); 
	NEW LINE 40 -> service.deleteMechanic(mechanic.id);